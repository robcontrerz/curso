import unittest

from selenium.webdriver.common.by import By

from common.base_test_1 import BaseTest1
from common.selenium_utils import print_element_info


class CSETest(BaseTest1):

    # Identify Lost your password link by Full text

    def test_01(self):
        lk_contact_us = self.driver.find_element(By.LINK_TEXT, "Forgotten Password")
        print_element_info("Link Contact Us", lk_contact_us)

    # Identify <-Back to blog by Partial Link Text
    # (contains <- and the name of the blog can change with blog

    def test_02(self):
        lk_olvidaste_contrasena = self.driver.find_element(By.PARTIAL_LINK_TEXT, "Forgot")
        print_element_info("Link olvidaste contraseña", lk_olvidaste_contrasena)


if __name__ == '__main__':
    unittest.main()
