import unittest

from selenium.webdriver.common.by import By

from common.base_test_1 import BaseTest1


class CSETest(BaseTest1):
    def test_01(self):
        # Identify UserName text field using By Name
        txt_email = self.driver.find_element( By.NAME, "email" )
        print(txt_email)


if __name__ == '__main__':
    unittest.main()
