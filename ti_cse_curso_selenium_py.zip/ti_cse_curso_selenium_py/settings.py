import os
root_dir = os.path.abspath(os.path.dirname(__file__))

