print("HOLA SELENIUM")

var1 = "cualquier cosa, esto es un string"
var2 = "David"

nombre = "Elizabeth"
ap_paterno = "Guevara"
ap_materno = "Roa"
edad = 20

nombre_completo = nombre + " " + ap_paterno + " " + ap_materno
print("NOMBRE: " + nombre_completo)
print("EDAD: " + str(edad) )



