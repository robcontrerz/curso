print('HOLA SELENIUM CON PYTHON')

curso = "Selenium"
lenguaje = "Python"
saludo = "¡Hola, Bienvenido al Curso: " + curso + " + " + lenguaje
print(saludo)



