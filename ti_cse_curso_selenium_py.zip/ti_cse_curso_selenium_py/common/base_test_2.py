import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from common.config import Configuration


class BaseTest2(unittest.TestCase):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__driver = None

    @property
    def driver(self):
        return self.__driver

    @driver.setter
    def driver(self, driver_instance):
        self.__driver = driver_instance

    def setUp(self):
        self.driver = Configuration.create_chrome_driver()
        self.wait = WebDriverWait(self.driver, 60)
        self.driver.get(Configuration.URL_LOGIN)
        self.driver.maximize_window()

        # Login
        txt_email = self.wait.until(expected_conditions.presence_of_element_located((By.ID, "input-email")))
        txt_email.send_keys(Configuration.EMAIL)
        txt_password = self.wait.until(expected_conditions.visibility_of_element_located((By.ID, "input-password")))
        txt_password.send_keys(Configuration.PASS)
        btn_sign_in = self.wait.until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@type='submit' and @value='Login']")))
        btn_sign_in.click()

        lbl_my_account = self.wait.until(expected_conditions.visibility_of_element_located( (By.XPATH, "//h2[contains(text(), 'My Account')]") ))
        self.assertTrue(lbl_my_account.is_displayed(), "Assert My Account page es visible")


    def tearDown(self):
        # Logout
        self.driver.get(Configuration.URL_LOGOUT)
        # Kill driver
        self.driver.quit()
