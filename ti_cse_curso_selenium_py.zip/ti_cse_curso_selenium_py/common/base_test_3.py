import unittest

from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from common.config import Configuration


class BaseTest3(unittest.TestCase):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__driver = None

    @property
    def driver(self):
        return self.__driver

    @driver.setter
    def driver(self, driver_instance):
        self.__driver = driver_instance

    def setUp(self):
        chrome_options = Options()
        chrome_options.headless = True

        self.driver = Configuration.create_chrome_driver(chrome_options)
        #self.driver = Configuration.create_chrome_driver()
        self.wait = WebDriverWait(self.driver, 60)
        self.driver.get(Configuration.URL_BASE)

    def tearDown(self):
        # Logout
        self.driver.get(Configuration.URL_LOGOUT)
        # Kill driver
        self.driver.quit()
