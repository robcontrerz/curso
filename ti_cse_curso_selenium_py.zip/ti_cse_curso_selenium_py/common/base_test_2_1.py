import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from common.config import Configuration


class BaseTest21(unittest.TestCase):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.__driver = None

    @property
    def driver(self):
        return self.__driver

    @driver.setter
    def driver(self, driver_instance):
        self.__driver = driver_instance

    def setUp(self):
        self.driver = Configuration.create_chrome_driver()
        self.wait = WebDriverWait(self.driver, 60)
        self.driver.maximize_window()

    def tearDown(self):
        # Kill driver
        self.driver.quit()
