def print_element_info(name, element):
    marker = "-" * 37
    print(marker)
    print("Element meta data: " + name)
    print(marker)
    print("WebElement object:: ", element)
    print("Outer HTML: ", element.get_attribute("outerHTML"))
    print("Inner HTML: ",  element.get_attribute("innerHTML"))
    print("Text: ", element.text)
    print("Value: ", element.get_attribute("value"))
    print("Tag: ", element.tag_name)
    print("Displayed: ", element.is_displayed())
    print("Selected: ", element.is_selected())
    print("Enabled: ", element.is_enabled())
    print(marker)


def switch_window_by_title(driver, titulo_ventana):
    for handle in driver.window_handles:
        driver.switch_to.window(handle)
        if driver.title == titulo_ventana:
            break