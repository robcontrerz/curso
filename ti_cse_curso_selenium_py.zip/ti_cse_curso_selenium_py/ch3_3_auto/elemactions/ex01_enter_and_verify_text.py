import unittest

from selenium.webdriver.common.by import By

from common.base_test_1 import BaseTest1
from common.config import Configuration


class CSETest(BaseTest1):
    def test_001_usuario(self):
        expected_user_name = Configuration.EMAIL
        txt_email = self.driver.find_element(By.ID, "input-email")
        self.assertTrue(txt_email.is_enabled(), "Assert, text email habilitado")

        #escribir email
        txt_email.send_keys(expected_user_name)
        actual_user_name = txt_email.get_attribute("value")
        self.assertEqual(expected_user_name, actual_user_name, "Assert el usuario ingresado vs el usuario esperado")

    def test_002_contrasena(self):
        expected_user_name = Configuration.PASS
        txt_email = self.driver.find_element(By.ID, "input-password")
        self.assertTrue(txt_email.is_enabled(), "Assert, text password habilitado")

        #escribir email
        txt_email.send_keys(expected_user_name)
        actual_user_name = txt_email.get_attribute("value")
        self.assertEqual(expected_user_name, actual_user_name, "Assert el password ingresado vs el password esperado")


if __name__ == '__main__':
    unittest.main()
