import time
import unittest

from selenium.webdriver.common.by import By

from common.config import Configuration


class CSETest(unittest.TestCase):
    def test_something(self):
        self.driver = Configuration.create_chrome_driver()
        self.driver.get(Configuration.URL_LOGIN)
        time.sleep(3)

        txt_email = self.driver.find_element(By.ID, "input-email")
        txt_email.send_keys(Configuration.EMAIL)
        txt_password = self.driver.find_element(By.ID, "input-password")
        txt_password.send_keys(Configuration.PASS)
        txt_password.submit()
        time.sleep(3)

        lbl_my_account = self.driver.find_element(By.XPATH, "//*[@class = 'col-sm-9']")
        self.assertTrue(lbl_my_account.is_displayed(), "Assert My Account page es visible")

        # LogOut

        self.driver.quit()


if __name__ == '__main__':
    unittest.main()
