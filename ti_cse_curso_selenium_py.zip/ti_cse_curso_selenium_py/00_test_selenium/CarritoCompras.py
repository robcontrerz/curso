import unittest


class CarritoCompras(unittest.TestCase):
    def test_agregar_producto(self):
        print("\nTEST AGREGAR PRODUCTO")
        self.assertEqual(True, False)  # add assertion here

    def test_modificar_cantidad(self):
        print("\nTEST MODIFICAR CANTIDAD")

    def test_eliminar_carrito(self):
        print("\nTEST ELIMINAR CARRITO")
        self.assertEqual("python", "python", "VALIDANDO TEXTO PYTHON")
        self.assertTrue(True, "SE VALIDA UN ASSERT TRUE")
        self.assertFalse(False, "SE VALIDA UN ASSERT FALSE")


if __name__ == '__main__':
    unittest.main()
