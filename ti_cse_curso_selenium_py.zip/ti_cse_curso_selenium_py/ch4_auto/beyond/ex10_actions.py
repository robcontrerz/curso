import time
import unittest

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions

from common.base_test_0 import BaseTest0


class CSETest(BaseTest0):
    def test_mousehover(self):

        menu = self.driver.find_element(By.XPATH,"//a[text()='Desktops']")
        submenu = self.driver.find_element(By.XPATH, "//a[text()='Mac (1)']")

        #1. CREAR OBJETO ACTION
        action = ActionChains(self.driver)

        #2. CONCATENAR ACCIONES CON "."
        action\
            .move_to_element(menu) \
            .pause(2) \
            .move_to_element(submenu)\
            .click(submenu)\
            .release()

        #3. PERFORM (REALIZA LAS ACCIONES)
        action.perform()

        time.sleep(5)

if __name__ == '__main__':
    unittest.main()
