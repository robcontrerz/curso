import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions

from common.base_test_2 import BaseTest2
from common.config import Configuration


class CSETest(BaseTest2):
    def test_(self):
        #ABRIR URL
        self.driver.get(Configuration.URL_CONTAC_US)

        #Obtener path y nombre del archivo a subir
        file_path = Configuration.get_upload_file_path("file-upload.jpg")

        #SUBIR ARCHIVO, TRATARLO COMO UN TEXT INPUT
        txt_archivo = self.driver.find_element(By.ID, "fileUpload")
        txt_archivo.send_keys(file_path)
        txt_archivo.submit()


if __name__ == '__main__':
    unittest.main()
