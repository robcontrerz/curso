import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait

from common.config import Configuration
from common.base_test_1 import BaseTest1


class CSETest(BaseTest1):
    def test(self):
        self.driver.get("https://www.google.com")
        self.assertTrue(self.driver.title)

if __name__ == '__main__':
    unittest.main()
