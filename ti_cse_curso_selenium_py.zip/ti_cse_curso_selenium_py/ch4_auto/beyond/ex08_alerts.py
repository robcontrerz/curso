import time
import unittest

from selenium.webdriver.support import expected_conditions

from common.base_test_2 import BaseTest2


class CSETest(BaseTest2):
    def test_(self):

        #1. ACCEPT
        self.driver.execute_script("alert('SELENIUM CON PYTHON')")
        time.sleep(3)
        alert = self.wait.until(expected_conditions.alert_is_present())
        alert.accept()

        #2. DISMiSS
        self.driver.execute_script("alert('SELENIUM CON PYTHON')")
        time.sleep(3)
        alert = self.wait.until(expected_conditions.alert_is_present())
        alert.dismiss()

        #3. GET TEXT
        self.driver.execute_script("alert('SELENIUM CON PYTHON')")
        time.sleep(3)
        alert = self.wait.until(expected_conditions.alert_is_present())
        print("TEXTO ALERTA: " + alert.text)


if __name__ == '__main__':
    unittest.main()
