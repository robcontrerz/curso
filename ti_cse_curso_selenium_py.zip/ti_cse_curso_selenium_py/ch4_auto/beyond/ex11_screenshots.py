import unittest

from common.base_test_2 import BaseTest2
from common.config import Configuration


class CSETest(BaseTest2):
    def test_(self):
        target_path = Configuration.get_screenshot_file_path("dashboard")
        self.driver.save_screenshot(target_path)

        self.driver.get("https://www.google.com.mx")
        target_path = Configuration.get_screenshot_file_path("google")
        self.driver.save_screenshot(target_path)

        self.driver.get(Configuration.URL_LOGIN)
        target_path = Configuration.get_screenshot_file_path("url_login")
        self.driver.save_screenshot(target_path)

if __name__ == '__main__':
    unittest.main()
