import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions

from common.base_test_2 import BaseTest2


class CSETest(BaseTest2):
    def test_(self):
        #1. BUSCAR Y ACCIONAR ELEMENTOS CON JS
        self.driver.execute_script("el = document.getElementById('search_query_top'); el.value = 'DRESSES';")
        time.sleep(5)
        self.driver.refresh()

        #2. BUSCAR ELEMENTO CON WEBDRIVER Y ACCIONAR CON JS
        txt_busqueda = self.driver.find_element(By.ID, "search_query_top")
        self.driver.execute_script("arguments[0].click()", txt_busqueda)
        self.driver.execute_script("arguments[0].value = arguments[1]", txt_busqueda, "BLOUSE")
        time.sleep(5)
        self.driver.refresh()

        #3. JS BUSCA EL ELEMENTO, Y WEBDRIVER LO ACCIONA
        txt_busqueda2 = self.driver.execute_script("return document.getElementById('search_query_top');")
        txt_busqueda2.send_keys("JEANS")
        time.sleep(5)


if __name__ == '__main__':
    unittest.main()
