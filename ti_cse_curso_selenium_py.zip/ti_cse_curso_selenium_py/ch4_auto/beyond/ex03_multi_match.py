import unittest

from selenium.webdriver.common.by import By

from common.base_test_2 import BaseTest2
from common.selenium_utils import print_element_info
from common.config import Configuration


class CSETest(BaseTest2):
    def test(self):
        #ABRIR URL CATEGORIA WOMEN
        self.driver.get(Configuration.URL_CAT_WOMEN)

        #ENCONTRAR TODOS LOS ELEMENTOS Y ALMACENARLOS EN 1 LISTA
        lbl_nombres_productos = self.driver.find_elements(By.XPATH, "//div[@class = 'product-container']//a[@class = 'product-name']")
        print("Check Box count: ", len(lbl_nombres_productos))

        for producto in lbl_nombres_productos:
            print(producto.get_attribute("title"))


if __name__ == '__main__':
    unittest.main()
