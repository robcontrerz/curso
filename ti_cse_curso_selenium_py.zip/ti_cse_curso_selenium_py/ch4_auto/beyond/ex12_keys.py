import unittest

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

from common.base_test_2 import BaseTest2


class CSETest(BaseTest2):
    def test_01(self):
        # Sending sequence Using Keys
        busqueda = "Sample"
        txt_busqueda = self.driver.find_element(By.NAME, "search")
        txt_busqueda.send_keys(Keys.SHIFT + busqueda)
        txt_busqueda.send_keys(Keys.ENTER)


    def test_02(self):
        # Holding and releasing a key while other keystrokes are simulated
        busqueda = "Sample"
        txt_busqueda = self.driver.find_element(By.NAME, "search")

        action_chain = ActionChains(self.driver)
        action_chain \
            .key_down(Keys.SHIFT) \
            .send_keys_to_element(txt_busqueda, busqueda) \
            .key_up(Keys.SHIFT) \
            .perform()


if __name__ == '__main__':
    unittest.main()
