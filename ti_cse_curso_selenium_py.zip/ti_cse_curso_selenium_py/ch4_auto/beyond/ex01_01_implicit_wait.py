import unittest

from selenium.webdriver.common.by import By

from common.config import Configuration
from common.base_test_1 import BaseTest1


class CSETest(BaseTest1):
    def test(self):
        #IMPLICIT WAIT
        self.driver.implicitly_wait(60)

        txt_email = self.driver.find_element(By.ID, "input-email")
        txt_email.send_keys(Configuration.EMAIL)
        txt_password = self.driver.find_element(By.ID, "input-password")
        txt_password.send_keys(Configuration.PASS)
        txt_password.submit()

        lbl_my_account = self.driver.find_element(By.XPATH, "//*[@class = 'col-sm-9']")
        self.assertTrue(lbl_my_account.is_displayed(), "Assert My Account page es visible")


if __name__ == '__main__':
    unittest.main()
