import time
import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.select import Select

from common.base_test_2 import BaseTest2
from common.config import Configuration


class CSETest(BaseTest2):

    # Handling a drop down list with clicks
    def test_01(self):
        #ABRIR URL PRODUCTO
        self.driver.get(Configuration.URL_PRODUCTO)

        #MANEJO DE LISTAS CON CLICKS
        sl_sort = self.wait.until(expected_conditions.presence_of_element_located((By.ID,"input-sort")))
        sl_sort.click()
        time.sleep(3)
        opt_price = self.wait.until(expected_conditions.presence_of_element_located((By.XPATH,"//*[contains(text(),'Price (High > Low)')]")))
        opt_price.click()
        time.sleep(3)


    # Handling a drop down list using send_keys
    def test_02(self):
        #ABRIR URL PRODUCTO
        self.driver.get(Configuration.URL_PRODUCTO)

        #MANEJO DE LISTAS CON CLICKS
        sl_talla = self.wait.until(expected_conditions.presence_of_element_located((By.ID, "input-limit")))
        sl_talla.send_keys("75")
        time.sleep(5)


    # Handling a drop down list  as a Select Control
    def test_03(self):
        #ABRIR URL PRODUCTO
        self.driver.get(Configuration.URL_PRODUCTO)

        #MANEJO DE LISTAS CON CLASE SELECT
        expected_size = "Model (A - Z)"
        sl_opcion = self.wait.until(expected_conditions.presence_of_element_located((By.ID, "input-sort")))
        lista_size = Select(sl_opcion)
        lista_size.select_by_visible_text(expected_size)
        #lista_size.select_by_index(2)
        #lista_size.select_by_value("http://opencart.abstracta.us:80/index.php?route=product/category&path=25_28&sort=rating&order=DESC")
        time.sleep(2)



if __name__ == '__main__':
    unittest.main()
