import unittest

from common.base_test_2 import BaseTest2
from common.config import Configuration
from common.selenium_utils import switch_window_by_title


class CSETest(BaseTest2):
    def test_(self):
        #OBTENER DATOS VENTANA PRINCIPAL
        main_win = self.driver.current_window_handle
        print("TITULO VENTANA ACTUAL: " + self.driver.title)
        print("WINDOWS HANDLE VENTANA ACTUAL: " + main_win)

        # CON JS ABRIMOS UNA NUEVA VENTANA/PESTAÑA
        self.driver.execute_script("window.open(arguments[0]);", Configuration.URL_PRODUCTO)

        #ITERAR WINDOWS HANDLES Y SWICHEARSE AL QUE NO SEA EL PRINCIPAL
        for handle in self.driver.window_handles:
            if handle != main_win:
                self.driver.switch_to.window(handle)
                print("TITULO VENTANA ACTUAL: " + self.driver.title)
                print("WINDOWS HANDLE VENTANA ACTUAL: " + self.driver.current_window_handle)
                self.driver.close()

        self.driver.switch_to.window(main_win)
        print("TITULO VENTANA ACTUAL: " + self.driver.title)
        print("WINDOWS HANDLE VENTANA ACTUAL: " + self.driver.current_window_handle)





if __name__ == '__main__':
    unittest.main()
