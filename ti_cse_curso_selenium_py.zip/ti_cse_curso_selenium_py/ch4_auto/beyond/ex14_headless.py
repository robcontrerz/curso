import unittest

from common.base_test_3 import BaseTest3
from common.config import Configuration

class CSETest(BaseTest3):
    def test_something(self):
        self.driver.get(Configuration.URL_LOGIN)


if __name__ == '__main__':
    unittest.main()
