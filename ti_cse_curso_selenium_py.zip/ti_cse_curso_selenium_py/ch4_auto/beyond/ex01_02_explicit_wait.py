import unittest

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait

from common.config import Configuration
from common.base_test_1 import BaseTest1


class CSETest(BaseTest1):
    def test(self):
        #EXPLICIT WATI
        self.wait = WebDriverWait(self.driver, 60)

        txt_email = self.wait.until(expected_conditions.presence_of_element_located( (By.ID, "input-email") ))
        txt_email.send_keys(Configuration.EMAIL)
        txt_password = self.wait.until(expected_conditions.visibility_of_element_located( (By.ID, "input-password") ))
        txt_password.send_keys(Configuration.PASS)
        btn_sign_in = self.wait.until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@type='submit' and @value='Login']")))
        btn_sign_in.click()

        lbl_my_account = self.wait.until(expected_conditions.visibility_of_element_located((By.XPATH, "//h2[contains(text(), 'My Account')]")))
        self.assertTrue(lbl_my_account.is_displayed(), "Assert My Account page es visible")


if __name__ == '__main__':
    unittest.main()
