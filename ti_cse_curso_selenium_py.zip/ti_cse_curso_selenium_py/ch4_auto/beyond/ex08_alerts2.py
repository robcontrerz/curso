import time
import unittest

from selenium.webdriver.support import expected_conditions

from common.base_test_2 import BaseTest2


class CSETest(BaseTest2):
    def test_alerts(self):
        # 1. ACCEPT
        self.driver.execute_script("alert('SELENIUM CON PYTHON')")
        time.sleep(3)
        alert = self.wait.until(expected_conditions.alert_is_present())
        alert.accept()


        # Crear ALERTA DUMMY con JS
        self.driver.execute_script("alert('TEST ALERT 2');")
        time.sleep(3)

        # Esperar y Get Text de la alerta
        self.wait.until(expected_conditions.alert_is_present())
        text = self.driver.switch_to.alert.text
        print("\n" + text)

        # Descartar Cerrar la alerta
        self.driver.switch_to.alert.dismiss()

#Ejercicio con url: https://demoqa.com/alerts
if __name__ == '__main__':
    unittest.main()
