import unittest
import time



from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from common.base_test_2_1 import BaseTest21
from common.config import Configuration


class CSETest(BaseTest21):

    def test_01(self):

        self.driver.get(Configuration.URL_FRAMES)

        #SWITCH A FRAME A
        self.driver.switch_to.frame("id_frame_a")
        frm_a = self.driver.find_element(By.ID, "id_input-frame_a")
        frm_a.send_keys("ESTE ES EL FRAME A")
        time.sleep(3)

        #SWITCH A CONTENIDO DEFAUTL
        self.driver.switch_to.default_content()

        #SWITCH A FRAME B
        self.driver.switch_to.frame("name_frame_b")
        txt_b = self.driver.find_element(By.ID, 'id_input-frame_b')
        txt_b.send_keys("ESTE ES EL FRAME B")
        time.sleep(3)


        # obtener frame C como WEBELEMENT
        frm_c = self.driver.find_element(By.ID, "id_frame_c")

        # SWITCH A FRAME C
        self.driver.switch_to.frame(frm_c)
        txt_c = self.driver.find_element(By.ID, 'id_input-frame_c')
        txt_c.send_keys("ESTE ES EL FRAME C")
        time.sleep(3)

        #SWITCH A CONTENIDO DEFAUTL
        self.driver.switch_to.default_content()

        # Interactura, escribir en el contenido default
        text = "ESTO ESTA EN EL CONENIDO DEFAULT"
        txt_contenido_default = self.driver.find_element(By.ID, "id_input-default")
        txt_contenido_default.send_keys(text)
        time.sleep(3)

if __name__ == '__main__':
    unittest.main()
